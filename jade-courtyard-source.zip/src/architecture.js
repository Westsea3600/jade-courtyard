/** Architecture is assembled entirely from cuboids and later batched by the voxel renderer. */
export function createArchitecture(THREE, voxel) {
  const group = new THREE.Group();
  group.name = 'The Jade Courtyard / architecture';
  const C = {
    red: '#9e3c30', redLight: '#b84b39', redDark: '#722d29',
    wood: '#633d2c', woodLight: '#875d3d', dark: '#24332e',
    jade: '#28584c', jadeLight: '#346a59', jadeDark: '#21483f',
    gold: '#c69a52', goldLight: '#dfbf77', stone: '#b2b0a0',
    stoneLight: '#cdc7b3', stoneDark: '#8e9488', ivory: '#d8cfb8',
    glow: '#efc982', black: '#26312b',
  };
  const B = (p, x, y, z, w, h, d, color, material = 'default', opts = {}) =>
    voxel.box(p, x, y, z, w, h, d, color, { material, ...opts });
  const make = (name, x, z, rotation = 0) => {
    const g = new THREE.Group();
    g.name = name;
    g.position.set(x, 0, z);
    g.rotation.y = rotation;
    group.add(g);
    return g;
  };

  function plinth(g, w, d, h = 1.65, main = false) {
    B(g, 0, .25, 0, w + 2.0, .5, d + 2.0, C.stoneDark, 'stone');
    B(g, 0, .67, 0, w + 1.25, .36, d + 1.25, C.stone, 'stone');
    B(g, 0, 1.06, 0, w + .65, .42, d + .65, C.stoneLight, 'stone');
    B(g, 0, h - .18, 0, w + .9, .36, d + .9, C.stoneLight, 'stone');
    // Recessed rectangular reliefs on the front and side of the raised terrace.
    for (let x = -w / 2 + 1; x < w / 2; x += 2.2) {
      B(g, x, .96, d / 2 + .38, 1.45, .36, .08, C.stoneDark, 'stone');
      B(g, x, .98, d / 2 + .44, .95, .2, .09, C.stone, 'stone');
    }
    const steps = 5, sw = main ? 10 : Math.min(w - 2, 6);
    for (let i = 0; i < steps; i++) {
      const top = h * (steps - i) / steps;
      B(g, 0, top / 2, d / 2 + .45 + i * .72,
        sw + (main ? .25 : 0), top, .8, i % 2 ? C.stone : C.stoneLight, 'stone');
    }
    for (const sign of [-1, 1]) {
      for (let i = 0; i < steps; i++) {
        const top = h * (steps - i) / steps;
        B(g, sign * (sw / 2 + .36), top + .16,
          d / 2 + .45 + i * .72, .48, .35, .8, C.stoneLight, 'stone');
      }
    }
    if (main) {
      // Low ceremonial balustrades leave the central staircase unobstructed.
      for (const side of [-1, 1]) {
        for (let x = sw / 2 + 1; x <= w / 2; x += 1.7) {
          B(g, x * side, h + .7, d / 2 + .1, .34, 1.35, .34, C.stoneLight, 'stone');
          B(g, x * side, h + 1.39, d / 2 + .1, .54, .18, .54, C.ivory, 'stone');
        }
        B(g, side * ((w + sw) / 4), h + .93, d / 2 + .1,
          (w - sw) / 2, .24, .26, C.stoneLight, 'stone');
      }
    }
  }

  function lantern(g, x, y, z, scale = 1) {
    B(g, x, y + .65 * scale, z, .11 * scale, .65 * scale, .11 * scale, C.gold, 'gold');
    B(g, x, y, z, .67 * scale, .86 * scale, .67 * scale, C.redLight, 'wood');
    B(g, x, y, z + .345 * scale, .44 * scale, .55 * scale, .06 * scale, C.glow, 'gold');
    B(g, x, y + .49 * scale, z, .84 * scale, .14 * scale, .84 * scale, C.gold, 'gold');
    B(g, x, y - .49 * scale, z, .75 * scale, .14 * scale, .75 * scale, C.gold, 'gold');
    B(g, x, y - .78 * scale, z, .12 * scale, .4 * scale, .12 * scale, C.gold, 'gold');
    B(g, x, y - .99 * scale, z, .26 * scale, .13 * scale, .26 * scale, C.redLight, 'wood');
  }

  function column(g, x, z, base, height, size = .68) {
    B(g, x, base + .12, z, size + .42, .24, size + .42, C.stoneLight, 'stone');
    B(g, x, base + .38, z, size + .18, .32, size + .18, C.stone, 'stone');
    B(g, x, base + height / 2 + .36, z, size, height - .55, size, C.red, 'wood');
    B(g, x, base + .68, z, size + .06, .17, size + .06, C.gold, 'gold');
    B(g, x, base + height - .24, z, size + .14, .2, size + .14, C.gold, 'gold');
  }

  function brackets(g, x, y, z, scale = 1) {
    // Three interlocking, progressively wider timber tiers suggest dougong.
    B(g, x, y, z, .68 * scale, .27 * scale, .68 * scale, C.gold, 'gold');
    B(g, x, y + .28 * scale, z, 1.12 * scale, .28 * scale, .5 * scale, C.woodLight, 'wood');
    B(g, x, y + .56 * scale, z, .6 * scale, .27 * scale, 1.55 * scale, C.redLight, 'wood');
    B(g, x, y + .81 * scale, z, 1.9 * scale, .26 * scale, .66 * scale, C.gold, 'gold');
    for (const a of [-1, 1]) {
      B(g, x + a * .67 * scale, y + .48 * scale, z,
        .35 * scale, .38 * scale, .52 * scale, C.red, 'wood');
      B(g, x, y + .73 * scale, z + a * .67 * scale,
        .48 * scale, .35 * scale, .35 * scale, C.woodLight, 'wood');
    }
  }

  function lattice(g, x, y, z, w = 2.3, h = 2.7) {
    B(g, x, y, z, w, h, .17, C.dark, 'dark');
    for (const s of [-1, 1]) B(g, x + s * w / 2, y, z + .12, .14, h + .24, .15, C.woodLight, 'wood');
    for (const s of [-1, 1]) B(g, x, y + s * h / 2, z + .12, w, .14, .15, C.gold, 'gold');
    const cols = Math.round(w / .46);
    for (let i = 1; i < cols; i++) B(g, x - w / 2 + i * w / cols, y, z + .14, .085, h, .13, C.woodLight, 'wood');
    for (let yy = -h / 2 + .45; yy < h / 2; yy += .48) B(g, x, y + yy, z + .17, w, .075, .13, C.woodLight, 'wood');
    B(g, x, y - h / 2 - .2, z, w + .25, .24, .5, C.redDark, 'wood');
  }

  function roof(g, width, depth, base, slope = .55, options = {}) {
    const hx = Math.round(width / 2), hz = Math.round(depth / 2);
    const pitch = options.pitch || 1;
    const lift = options.lift ?? 1.0;
    const ridgeHeight = base + hz * slope;
    const gableRise = hz * .45;
    const gableEnd = hx - gableRise * .8;
    const gablePlane = -hx + Math.ceil((gableEnd + hx) / pitch - .5) * pitch;
    // Adjacent hip tiles can rise .78 units. Keep slabs overlapping vertically,
    // growing them downward so every visible tile top and roof silhouette stays fixed.
    const tileThickness = .99;
    const tileOffset = (tileThickness - .61) / 2;
    const profile = (x, z) => {
      const alongDepth = hz - Math.abs(z);
      const alongEnd = (hx - Math.abs(x)) / (options.pyramid ? 1 : .8);
      const inner = options.halfHip
        ? Math.abs(x) < gableEnd ? alongDepth : Math.min(alongDepth, alongEnd, gableRise)
        : Math.min(alongDepth, alongEnd);
      const cx = Math.pow(Math.max(0, (Math.abs(x) / hx - .56) / .44), 2.1);
      const cz = Math.pow(Math.max(0, (Math.abs(z) / hz - .53) / .47), 2.1);
      return base + Math.round((Math.max(0, inner) * slope + lift * cx * cz) / .26) * .26;
    };
    // The roof surface is individual deep blocks. Raised outer corners form the flying eaves.
    for (let x = -hx + pitch / 2; x < hx; x += pitch) {
      for (let z = -hz + pitch / 2; z < hz; z += pitch) {
        const yy = profile(x, z);
        const edge = Math.abs(x) > hx - pitch * 1.1 || Math.abs(z) > hz - pitch * 1.1;
        const n = Math.abs(Math.round(x * 31 + z * 17)) % 9;
        const color = n < 2 ? C.jadeLight : n === 3 ? C.jadeDark : C.jade;
        B(g, x, yy - tileOffset, z, pitch + .025, tileThickness, pitch + .025, color, 'roof');
        // Slim long ribs catch the light across the tiled eave.
        if (Math.round(x + hx) % 2 === 0) B(g, x, yy + .335, z, .13, .10, pitch + .04, C.jadeLight, 'roof');
        if (edge) B(g, x, yy - .34, z, pitch + .045, .13, pitch + .045, C.gold, 'gold');
      }
    }
    // Visible dark timber edge below the tile overhang.
    B(g, 0, base - .62, hz - 1.4, width - 2.8, .33, .43, C.wood, 'wood');
    B(g, 0, base - .62, -hz + 1.4, width - 2.8, .33, .43, C.wood, 'wood');
    if (options.halfHip) {
      // Raised timber gables above the lower hipped skirt distinguish a xieshan roof.
      for (const side of [-1, 1]) {
        for (let z = -hz + gableRise + .35; z < hz - gableRise; z += .7) {
          const rise = (hz - Math.abs(z) - gableRise) * slope;
          if (rise <= 0) continue;
          B(g, side * gablePlane, base + gableRise * slope + rise / 2,
            z, .4, rise + .18, .71, C.wood, 'wood');
          B(g, side * (gablePlane + .12), base + gableRise * slope + rise - .08,
            z, .45, .15, .73, C.gold, 'gold');
        }
      }
    }
    const ridgeHalf = options.pyramid ? 0 : options.halfHip ? gableEnd - .5 : Math.max(0, hx - hz * .8);
    B(g, 0, ridgeHeight + .18, 0, ridgeHalf * 2 + .7, .47, .65, C.gold, 'gold');
    B(g, 0, ridgeHeight + .48, 0, ridgeHalf * 2 + .1, .18, .33, C.goldLight, 'gold');
    for (const s of options.pyramid ? [] : [-1, 1]) {
      // Block-stepped chiwen ornaments, rising above either end of the ridge.
      const rx = s * (ridgeHalf + .1);
      for (let i = 0; i < 3; i++) B(g, rx + s * i * .27, ridgeHeight + .55 + i * .3, 0,
        .48, .4, .56 - i * .08, i === 2 ? C.goldLight : C.gold, 'gold');
      B(g, rx + s * .65, ridgeHeight + 1.35, 0, .24, .45, .3, C.gold, 'gold');
    }
    if (options.pyramid) {
      B(g, 0, ridgeHeight + .67, 0, .38, .43, .38, C.gold, 'gold');
      B(g, 0, ridgeHeight + 1.00, 0, .2, .28, .2, C.goldLight, 'gold');
    }
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
      const yy = profile(sx * (hx - .5), sz * (hz - .5));
      B(g, sx * (hx - .19), yy + .22, sz * (hz - .19), .49, .44, .49, C.gold, 'gold');
      B(g, sx * (hx + .12), yy + .52, sz * (hz + .12), .32, .37, .32, C.goldLight, 'gold');
    }
    return ridgeHeight;
  }

  function hall(g, { w, d, h, base = 1.65, isMain = false, title = false }) {
    plinth(g, w + .4, d + .4, base, isMain);
    const wallTop = base + h;
    B(g, 0, base + h / 2, -d / 2 + .36, w - .4, h, .7, C.red, 'wood');
    for (const s of [-1, 1]) {
      B(g, s * (w / 2 - .36), base + h / 2, 0, .7, h, d - .6, C.redDark, 'wood');
      B(g, s * (w / 2 - .78), base + 1.1, 0, .14, 1.6, d - 1, C.red, 'wood');
    }
    const doorWidth = isMain ? 5.1 : 3.3;
    B(g, 0, base + h / 2, d / 2 - .9, doorWidth, h - .4, .28, C.black, 'dark');
    // Warm recessed inner doorway gives depth without introducing a flat painted facade.
    B(g, 0, base + h * .43, d / 2 - 1.15, doorWidth - 1.1, h * .64, .12, '#9d7545', 'gold');
    B(g, 0, base + h * .41, d / 2 - 1.04, doorWidth - 1.9, h * .59, .1, '#c49b60', 'gold');
    for (const s of [-1, 1]) {
      const panelW = (w - doorWidth) / 2 - .7;
      const panelX = s * (doorWidth / 2 + panelW / 2 + .15);
      B(g, panelX, base + h / 2, d / 2 - .3, panelW, h, .55, C.red, 'wood');
      const count = isMain ? 2 : 1;
      for (let j = 0; j < count; j++) {
        const xx = panelX + (j - (count - 1) / 2) * (panelW / count);
        lattice(g, xx, base + h * .55, d / 2 + .01,
          Math.min(2.45, panelW / count - .45), h * .49);
      }
      // Red doors are pulled open to either side of the luminous central bay.
      B(g, s * (doorWidth / 2 - .15), base + h * .42, d / 2 + .32,
        .48, h * .79, 1.48, C.redDark, 'wood', { rotation: s * .16 });
      for (let yy = 0; yy < 4; yy++) B(g, s * (doorWidth / 2 - .44), base + 1 + yy * .78,
        d / 2 + .99, .12, .12, .08, C.gold, 'gold');
    }
    B(g, 0, wallTop - .45, d / 2, w, .65, .62, C.wood, 'wood');
    B(g, 0, wallTop - .07, d / 2 + .11, w + .7, .18, .75, C.gold, 'gold');
    // End the low wall at the jambs so the central doorway meets the terrace floor.
    for (const s of [-1, 1]) {
      B(g, s * (w + doorWidth) / 4, base + .23, d / 2 + .05,
        (w - doorWidth) / 2, .46, .65, C.redDark, 'wood');
    }
    const cols = isMain ? 7 : 5;
    const frontColumnSize = isMain ? .75 : .62;
    const columnFootHalf = (frontColumnSize + .42) / 2;
    for (let i = 0; i < cols; i++) {
      const x = -w / 2 + .3 + i * (w - .6) / (cols - 1);
      // Reserve the entire door bay, including clearance for the stone column feet.
      if (Math.abs(x) - columnFootHalf >= doorWidth / 2 + .2) {
        column(g, x, d / 2 + .6, base, h + .1, frontColumnSize);
        brackets(g, x, wallTop - .1, d / 2 + .6, isMain ? 1 : .82);
      }
      column(g, x, -d / 2 + .15, base, h + .1, .62);
      brackets(g, x, wallTop - .1, -d / 2 + .15, isMain ? .92 : .78);
    }
    for (const s of [-1, 1]) {
      for (let z = -d / 2 + 2.5; z < d / 2 - 1; z += 3.3) {
        column(g, s * (w / 2 - .25), z, base, h + .1, .6);
        brackets(g, s * (w / 2 - .25), wallTop - .1, z, .8);
      }
      lantern(g, s * (isMain ? 5.8 : 3.8), wallTop - 1.25, d / 2 + 1.12, isMain ? 1.03 : .82);
    }
    if (title) {
      B(g, 0, wallTop - .38, d / 2 + .53, isMain ? 5.3 : 3.8, 1.08, .25, C.jadeDark, 'dark');
      for (const s of [-1, 1]) B(g, 0, wallTop - .38 + s * .58, d / 2 + .58,
        isMain ? 5.65 : 4.1, .12, .37, C.gold, 'gold');
      // Three small raised seal-like timber motifs read well from the overview camera.
      for (let i = -1; i <= 1; i++) {
        const xx = i * (isMain ? 1.15 : .83);
        B(g, xx, wallTop - .38, d / 2 + .7, .15, .61, .1, C.goldLight, 'gold');
        B(g, xx, wallTop - .38, d / 2 + .7, .52, .12, .1, C.goldLight, 'gold');
        B(g, xx - .2, wallTop - .16, d / 2 + .7, .12, .3, .1, C.goldLight, 'gold');
      }
    }
  }

  function lion(g, x, z, facing = 0) {
    const l = new THREE.Group();
    l.position.set(x, 0, z); l.rotation.y = facing; g.add(l);
    B(l, 0, .28, 0, 2.15, .56, 2.4, C.stoneDark, 'stone');
    B(l, 0, .66, 0, 1.95, .22, 2.15, C.stoneLight, 'stone');
    B(l, 0, 1.43, -.13, 1.28, 1.35, 1.3, C.stone, 'stone');
    B(l, 0, 2.31, .37, 1.48, 1.35, 1.23, C.stoneLight, 'stone');
    B(l, 0, 2.16, 1.08, .96, .52, .58, C.stone, 'stone');
    B(l, 0, 2.64, 1.13, .53, .28, .45, C.stoneDark, 'stone');
    for (const s of [-1, 1]) {
      B(l, s * .62, 2.99, .3, .36, .5, .5, C.stone, 'stone');
      B(l, s * .5, 2.57, 1.005, .17, .16, .12, C.dark, 'dark');
      B(l, s * .68, 1.21, .73, .48, .9, .85, C.stoneLight, 'stone');
      B(l, s * .76, .91, 1, .59, .27, .72, C.stone, 'stone');
      for (let k = 0; k < 3; k++) B(l, s * .79, 1.88 + k * .37, .05 - k * .13,
        .33, .4, .65, C.stoneDark, 'stone');
    }
    B(l, 0, 1.48, -1.01, .33, .79, .39, C.stone, 'stone');
    B(l, 0, 1.93, -1.08, .45, .36, .44, C.stoneLight, 'stone');
  }

  // Main hall: the high double-eave roof anchors the north end of the central axis.
  const main = make('01 / 太和殿 · main hall', 0, -20);
  hall(main, { w: 24, d: 13, h: 5.9, isMain: true, title: true });
  roof(main, 32, 20, 8.35, .53, { lift: 1.55 });
  B(main, 0, 11.95, 0, 19.4, 2.5, 7.6, C.red, 'wood');
  for (let x = -9; x <= 9; x += 3) {
    B(main, x, 12.05, 3.87, .44, 2.2, .45, C.redLight, 'wood');
    brackets(main, x, 12.7, 4, .72);
    if (Math.abs(x) < 8) lattice(main, x + 1.5, 12.12, 3.88, 1.7, 1.18);
  }
  roof(main, 26, 16, 13.55, .61, { lift: 1.3 });
  for (const s of [-1, 1]) lion(main, s * 7.4, 11.15, s * -.1);

  // Mirror-paired side halls face toward the courtyard, preserving an open axial approach.
  const west = make('02 / 西配殿 · west hall', -25, -4, Math.PI / 2);
  hall(west, { w: 18, d: 9.8, h: 4.55, title: true });
  roof(west, 22, 14, 6.96, .56, { lift: 1.2, halfHip: true });
  const east = make('03 / 东配殿 · east hall', 25, -4, -Math.PI / 2);
  hall(east, { w: 18, d: 9.8, h: 4.55, title: true });
  roof(east, 22, 14, 6.96, .56, { lift: 1.2, halfHip: true });

  // Open triple-bay mountain gate. The central bay remains visually open through the wall.
  const gate = make('04 / 山门 · mountain gate', 0, 29);
  plinth(gate, 18, 6.8, 1.15);
  for (const s of [-1, 1]) {
    B(gate, s * 6.6, 3.75, 0, 4.5, 5.2, 5.2, C.red, 'wood');
    lattice(gate, s * 6.6, 3.93, 2.68, 2.6, 2.45);
    B(gate, s * 3.7, 3.45, .3, .55, 4.7, 3.2, C.redDark, 'wood', { rotation: s * .18 });
    for (const z of [-2.9, 2.9]) {
      for (const x of [3.75, 9.0]) {
        column(gate, s * x, z, 1.15, 5.55, .75);
        brackets(gate, s * x, 6.35, z, .85);
      }
    }
    lantern(gate, s * 3.0, 5.12, 3.45, .93);
    B(gate, s * 9.8, 1.54, 0, .48, .6, 6.1, C.stoneLight, 'stone');
  }
  B(gate, 0, 6.35, 0, 19.2, 1, 6.1, C.redDark, 'wood');
  B(gate, 0, 6.45, 3.15, 5.15, 1.4, .3, C.jadeDark, 'dark');
  for (const y of [5.71, 7.19]) B(gate, 0, y, 3.23, 5.5, .15, .43, C.gold, 'gold');
  for (let i = -1; i <= 1; i++) {
    B(gate, i * 1.15, 6.47, 3.33, .15, .75, .1, C.goldLight, 'gold');
    B(gate, i * 1.15, 6.47, 3.33, .61, .15, .1, C.goldLight, 'gold');
  }
  roof(gate, 24, 12, 7.6, .52, { lift: 1.15 });

  function tower(name, x, z, instrument = 'bell') {
    const t = make(name, x, z);
    plinth(t, 8.1, 8.1, 1.3);
    B(t, 0, 2.82, 0, 6.9, 3.05, 6.9, C.redDark, 'wood');
    for (const s of [-1, 1]) {
      lattice(t, s * 1.65, 2.9, 3.5, 1.75, 2.1);
      for (const zc of [-3.3, 3.3]) {
        column(t, s * 3.3, zc, 1.3, 4.85, .65);
        brackets(t, s * 3.3, 5.7, zc, .78);
      }
    }
    roof(t, 12, 12, 6.5, .55, { lift: .95, pyramid: true });
    // Open upper pavilions expose the paired bell and drum instruments.
    for (let floor = 0; floor < 2; floor++) {
      const yy = 9.25 + floor * 4.35;
      const size = floor === 0 ? 5.5 : 4.3;
      B(t, 0, yy, 0, size + 1.3, .48, size + 1.3, C.redDark, 'wood');
      B(t, 0, yy + .28, 0, size + 1.55, .12, size + 1.55, C.gold, 'gold');
      for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
        column(t, sx * size / 2, sz * size / 2, yy + .3, 2.5, .47);
        brackets(t, sx * size / 2, yy + 2.55, sz * size / 2, .63);
      }
      for (const s of [-1, 1]) {
        B(t, 0, yy + .87, s * size / 2, size, .16, .19, C.redLight, 'wood');
        B(t, s * size / 2, yy + .87, 0, .19, .16, size, C.redLight, 'wood');
        for (let p = -size / 2 + .55; p < size / 2; p += .75) {
          B(t, p, yy + .58, s * size / 2, .12, .7, .12, C.red, 'wood');
          B(t, s * size / 2, yy + .58, p, .12, .7, .12, C.red, 'wood');
        }
      }
      if (floor === 0) {
        if (instrument === 'drum') {
          for (const side of [-1, 1]) {
            B(t, side * 1.1, yy + 1.02, 0, .24, 1.58, .33, C.red, 'wood');
            B(t, side * 1.1, yy + .35, 0, .47, .2, 1.95, C.wood, 'wood');
          }
          B(t, 0, yy + 1.1, 0, 2.55, .2, .3, C.redLight, 'wood');
          // Square cross-section cells approximate a circular drum without a cylinder mesh.
          for (let dx = -.9; dx <= .91; dx += .3) for (let dy = -.9; dy <= .91; dy += .3) {
            if (dx * dx + dy * dy > .94) continue;
            B(t, dx, yy + 1.58 + dy, 0, .305, .305, 1.55, C.redDark, 'wood');
            for (const face of [-1, 1]) B(t, dx, yy + 1.58 + dy, face * .81,
              .305, .305, .12, C.ivory, 'stone');
          }
          for (let i = 0; i < 12; i++) {
            const angle = i * Math.PI / 6;
            B(t, Math.cos(angle) * .93, yy + 1.58 + Math.sin(angle) * .93,
              .91, .12, .12, .1, C.gold, 'gold');
          }
        } else {
          B(t, 0, yy + 2.05, 0, .16, .9, .16, C.gold, 'gold');
          B(t, 0, yy + 1.42, 0, 1.02, 1.1, 1.02, '#98754b', 'gold');
          B(t, 0, yy + .82, 0, 1.46, .23, 1.46, C.gold, 'gold');
        }
      }
      roof(t, floor === 0 ? 10 : 8, floor === 0 ? 10 : 8, yy + 3.3, .5, { lift: .9, pyramid: true });
    }
    // A tall square finial emphasizes the slender pagoda silhouette.
    B(t, 0, 19.95, 0, .83, .4, .83, C.gold, 'gold');
    B(t, 0, 20.5, 0, .43, .8, .43, C.goldLight, 'gold');
    B(t, 0, 21.03, 0, .21, .43, .21, C.gold, 'gold');
    return t;
  }
  tower('05 / 钟楼 · bell tower', -31, 24);
  tower('06 / 鼓楼 · drum tower', 31, 24, 'drum');

  const landmarks = [
    { id: 'main', name: '太和殿', english: 'Grand Hall', position: [0, 18.9, -20], target: [0, 8, -20], camera: [26, 23, 9], description: '重檐庑殿，金脊青瓦。层叠斗拱托起中轴线上的主殿。' },
    { id: 'west', name: '西配殿', english: 'West Hall', position: [-25, 12.1, -4], target: [-24, 5, -4], camera: [-5, 17, 17], description: '歇山屋顶上部立起木构山墙，朱柱与木格窗面向庭院。' },
    { id: 'east', name: '东配殿', english: 'East Hall', position: [25, 12.1, -4], target: [24, 5, -4], camera: [5, 17, 17], description: '与西配殿遥相呼应，围合出宽敞而宁静的礼仪庭院。' },
    { id: 'gate', name: '山门', english: 'Mountain Gate', position: [0, 12.5, 29], target: [0, 4.5, 29], camera: [20, 17, 55], description: '穿过红柱山门，沿石铺御道进入层层展开的院落。' },
    { id: 'tower-west', name: '钟楼', english: 'Bell Tower', position: [-31, 22.3, 24], target: [-31, 10, 24], camera: [-10, 21, 46], description: '三层攒尖飞檐逐级收分，铜钟悬于敞开的木构楼阁。' },
    { id: 'tower-east', name: '鼓楼', english: 'Drum Tower', position: [31, 22.3, 24], target: [31, 10, 24], camera: [51, 21, 43], description: '木架上的大鼓与西侧铜钟相应，三层攒尖飞檐托起金色宝顶。' },
  ];
  return { group, landmarks };
}
