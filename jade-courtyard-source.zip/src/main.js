import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { VoxelBatch } from './voxels.js';
import { createArchitecture } from './architecture.js';
import { createLandscape } from './landscape.js';
import './style.css';

const $ = (selector) => document.querySelector(selector);
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
const container = $('#scene');
let renderer;

try {
  renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
} catch (error) {
  $('#loading').remove();
  const message = document.createElement('div');
  message.className = 'fatal-error';
  message.innerHTML = '<strong>暂时无法开启 3D 场景</strong>请使用支持 WebGL 2 的现代浏览器，并在浏览器设置中启用图形加速后重新打开。';
  container.append(message);
  throw error;
}

renderer.setPixelRatio(Math.min(devicePixelRatio, innerWidth < 700 ? 1.5 : 1.75));
renderer.setSize(innerWidth, innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.12;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
container.appendChild(renderer.domElement);
renderer.domElement.setAttribute('aria-hidden', 'true');

const scene = new THREE.Scene();
scene.fog = new THREE.Fog('#ece9dd', 160, 330);
const camera = new THREE.OrthographicCamera(-90, 90, 55, -55, .1, 500);
const overviewPosition = new THREE.Vector3(79, 70, 96);
const overviewTarget = new THREE.Vector3(0, 3, 1);
camera.position.copy(overviewPosition);
const controls = new OrbitControls(camera, renderer.domElement);
controls.target.copy(overviewTarget);
controls.enableDamping = true;
controls.dampingFactor = .065;
controls.rotateSpeed = .65;
controls.zoomSpeed = .8;
controls.panSpeed = .6;
controls.minZoom = .65;
controls.maxZoom = 4.2;
controls.minPolarAngle = .10;
controls.maxPolarAngle = Math.PI / 2.12;
controls.autoRotateSpeed = .45;
controls.enablePan = true;
controls.update();

const hemi = new THREE.HemisphereLight('#f4f2df', '#67715c', 1.8);
scene.add(hemi);
const sun = new THREE.DirectionalLight('#fff0cf', 3.15);
sun.position.set(-45, 85, 55);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
Object.assign(sun.shadow.camera, { left: -72, right: 72, top: 72, bottom: -72, near: 1, far: 230 });
sun.shadow.normalBias = .045;
sun.shadow.bias = -.00012;
sun.shadow.camera.updateProjectionMatrix();
sun.target.position.set(0, 0, 0);
scene.add(sun, sun.target);
const fill = new THREE.DirectionalLight('#dce7e7', .75);
fill.position.set(55, 25, -65);
scene.add(fill);

const shadow = new THREE.Mesh(new THREE.PlaneGeometry(500, 500), new THREE.ShadowMaterial({ color: '#54634c', opacity: .16 }));
shadow.rotation.x = -Math.PI / 2;
shadow.position.y = -4.12;
shadow.receiveShadow = true;
scene.add(shadow);

const voxel = new VoxelBatch(THREE);
const landscape = createLandscape(THREE, voxel);
const architecture = createArchitecture(THREE, voxel);
scene.add(landscape.group, architecture.group);
const voxelMeshes = voxel.build(scene);
$('#voxel-count').textContent = `${new Intl.NumberFormat('zh-CN').format(voxel.count)} 块体素`;

// Sparse square motes lend depth without adding another heavy render pass.
const random = (n) => { const v = Math.sin(n * 78.233 + 19.19) * 43758.5453; return v - Math.floor(v); };
const motes = new THREE.InstancedMesh(new THREE.BoxGeometry(.09, .09, .09), new THREE.MeshBasicMaterial({ color: '#d8b66c', transparent: true, opacity: .38, depthWrite: false }), 65);
const moteTransform = new THREE.Object3D();
function updateMotes(t) {
  for (let i = 0; i < 65; i++) {
    moteTransform.position.set((random(i + 7) - .5) * 81 + Math.sin(t * .16 + i) * .7,
      2 + random(i + 192) * 20 + Math.sin(t * .28 + i) * .6,
      (random(i + 83) - .5) * 71 + Math.cos(t * .12 + i) * .7);
    moteTransform.updateMatrix();
    motes.setMatrixAt(i, moteTransform.matrix);
  }
  motes.instanceMatrix.needsUpdate = true;
}
updateMotes(0);
scene.add(motes);

let selected = null;
let tween = null;
let topView = false;
let lightMode = 'day';
let toastTimeout;
let lightTween = null;
const lighting = {
  morning: { sun: '#ffe0ad', sky: '#f5ebd2', ground: '#687562', fill: '#bfd9e5', intensity: 2.8, hemi: 1.65, exposure: 1.12, position: [-67, 45, 35], bg: ['#faf0dc', '#eee7d7', '#e3dfcd'] },
  day: { sun: '#fff0cf', sky: '#f4f2df', ground: '#67715c', fill: '#dce7e7', intensity: 3.15, hemi: 1.8, exposure: 1.12, position: [-45, 85, 55], bg: ['#f7f5ed', '#eeece3', '#e5e2d6'] },
  dusk: { sun: '#ffbd8b', sky: '#c8c6da', ground: '#555f63', fill: '#a5bdd3', intensity: 2.5, hemi: 1.25, exposure: 1.13, position: [-68, 32, -25], bg: ['#e9d4c3', '#d7cfcb', '#bebfc3'] },
};

function showToast(message) {
  $('#toast').textContent = message;
  $('#toast').classList.add('visible');
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => $('#toast').classList.remove('visible'), 2200);
}

function stopOrbit() {
  controls.autoRotate = false;
  $('#orbit').setAttribute('aria-pressed', 'false');
}

function moveCamera(position, target, zoom = 1) {
  stopOrbit();
  tween = {
    time: performance.now(), duration: reducedMotion ? 0 : 1250,
    fromPosition: camera.position.clone(), toPosition: new THREE.Vector3(...position),
    fromTarget: controls.target.clone(), toTarget: new THREE.Vector3(...target),
    fromZoom: camera.zoom, toZoom: zoom,
  };
}

function setNote(landmark = null) {
  selected = landmark?.id || null;
  $('#app').classList.toggle('detail-mode', Boolean(landmark));
  $('#note-index').textContent = landmark ? `${String(architecture.landmarks.indexOf(landmark) + 1).padStart(2, '0')} / ${landmark.english.toUpperCase()}` : '01 — 06';
  $('#note-title').textContent = landmark ? landmark.name : '中轴有序 · 庭院深深';
  $('#note-description').textContent = landmark ? landmark.description : '歇山飞檐 / 朱柱青瓦 / 对称院落';
  document.querySelectorAll('.landmark').forEach((button) => button.classList.toggle('active', button.dataset.id === selected));
}

function focusLandmark(id) {
  const landmark = architecture.landmarks.find((entry) => entry.id === id);
  if (!landmark) return;
  topView = false;
  $('#top-view').setAttribute('aria-pressed', 'false');
  setNote(landmark);
  moveCamera(landmark.camera, landmark.target, id.startsWith('tower') ? 2.35 : 2.1);
  if (innerWidth < 700) toggleGuide(false);
}

function resetView() {
  topView = false;
  $('#top-view').setAttribute('aria-pressed', 'false');
  setNote();
  moveCamera(overviewPosition.toArray(), overviewTarget.toArray(), 1);
}

function toggleGuide(force) {
  const open = typeof force === 'boolean' ? force : $('#guide').hidden;
  $('#guide').hidden = !open;
  $('#guide-toggle').setAttribute('aria-expanded', String(open));
  $('#guide-toggle').classList.toggle('active', open);
}

function setLighting(mode) {
  const preset = lighting[mode];
  if (!preset) return;
  lightMode = mode;
  document.querySelectorAll('[data-light]').forEach((button) => {
    button.classList.toggle('selected', button.dataset.light === mode);
    button.setAttribute('aria-pressed', String(button.dataset.light === mode));
  });
  lightTween = {
    start: performance.now(), duration: reducedMotion ? 0 : 900, preset,
    sun: sun.color.clone(), sky: hemi.color.clone(), ground: hemi.groundColor.clone(), fill: fill.color.clone(),
    intensity: sun.intensity, hemi: hemi.intensity, exposure: renderer.toneMappingExposure, position: sun.position.clone(),
  };
  $('#app').style.background = `radial-gradient(ellipse at 62% 40%,${preset.bg[0]} 0%,${preset.bg[1]} 56%,${preset.bg[2]} 100%)`;
  scene.fog.color.set(preset.bg[1]);
}

for (const [i, landmark] of architecture.landmarks.entries()) {
  const button = document.createElement('button');
  button.className = 'landmark';
  button.dataset.id = landmark.id;
  button.innerHTML = `<span class="landmark-number">${String(i + 1).padStart(2, '0')}</span><span><strong>${landmark.name}</strong><small>${landmark.english}</small></span><span>↗</span>`;
  button.addEventListener('click', () => focusLandmark(landmark.id));
  $('#landmark-list').appendChild(button);
}

$('#explore').addEventListener('click', () => focusLandmark('main'));
$('#overview-nav').addEventListener('click', () => { resetView(); toggleGuide(false); });
$('.brand').addEventListener('click', (event) => { event.preventDefault(); resetView(); });
$('#guide-toggle').addEventListener('click', () => toggleGuide());
$('#guide-close').addEventListener('click', () => toggleGuide(false));
$('#guide-overview').addEventListener('click', resetView);
$('#reset').addEventListener('click', () => { resetView(); showToast('已回到庭院全景'); });
$('#orbit').addEventListener('click', () => {
  tween = null;
  controls.autoRotate = !controls.autoRotate;
  $('#orbit').setAttribute('aria-pressed', String(controls.autoRotate));
  showToast(controls.autoRotate ? '自动环游已开启 · 拖拽可暂停' : '自动环游已暂停');
});
$('#top-view').addEventListener('click', () => {
  topView = !topView;
  $('#top-view').setAttribute('aria-pressed', String(topView));
  if (topView) { setNote(); moveCamera([0, 145, 1.1], [0, 0, 1], 1.05); }
  else resetView();
});
document.querySelectorAll('[data-light]').forEach((button) => button.addEventListener('click', () => setLighting(button.dataset.light)));
$('#fullscreen').addEventListener('click', async () => {
  try {
    if (document.fullscreenElement) await document.exitFullscreen();
    else if (document.documentElement.requestFullscreen) await document.documentElement.requestFullscreen();
    else showToast('当前浏览器暂不支持全屏，请使用浏览器的全屏功能');
  } catch { showToast('可按 F11 使用浏览器全屏观看'); }
});
document.addEventListener('fullscreenchange', () => {
  $('#fullscreen').setAttribute('aria-label', document.fullscreenElement ? '退出全屏' : '全屏观看');
});
window.addEventListener('keydown', (event) => {
  if (event.code === 'Escape') {
    if (!$('#guide').hidden) {
      toggleGuide(false);
      $('#guide-toggle').focus();
    }
    return;
  }
  if (event.target instanceof HTMLElement && event.target.closest('button, a, input, textarea, select')) return;
  if (event.code === 'KeyR') resetView();
  if (event.code === 'Space') { event.preventDefault(); $('#orbit').click(); }
});
controls.addEventListener('start', () => { tween = null; stopOrbit(); });

// A stationary click on an actual building opens its architectural detail.
const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();
let pointerStart;
renderer.domElement.addEventListener('pointerdown', (event) => { pointerStart = [event.clientX, event.clientY, performance.now()]; });
renderer.domElement.addEventListener('pointerup', (event) => {
  if (!pointerStart || event.button !== 0 || Math.hypot(event.clientX - pointerStart[0], event.clientY - pointerStart[1]) > 5 || performance.now() - pointerStart[2] > 500) return;
  pointer.set(event.clientX / innerWidth * 2 - 1, -event.clientY / innerHeight * 2 + 1);
  raycaster.setFromCamera(pointer, camera);
  const hit = raycaster.intersectObjects(voxelMeshes, false)[0];
  if (!hit || hit.point.y < 2.1) return;
  const nearest = architecture.landmarks.map((landmark) => ({ landmark, distance: Math.hypot(hit.point.x - landmark.target[0], hit.point.z - landmark.target[2]) }))
    .sort((a, b) => a.distance - b.distance)[0];
  if (nearest.distance < (nearest.landmark.id === 'main' ? 18 : 12)) focusLandmark(nearest.landmark.id);
});

function resize() {
  const width = innerWidth, height = innerHeight, aspect = width / height;
  const vertical = aspect < 1.15 ? Math.max(123, 137 / aspect) : 107;
  camera.left = -vertical * aspect / 2;
  camera.right = vertical * aspect / 2;
  camera.top = vertical / 2;
  camera.bottom = -vertical / 2;
  const offset = width < 700 ? -.015 : -.068;
  camera.setViewOffset(width, height, width * offset, width < 700 ? -height * .035 : -height * .012, width, height);
  camera.updateProjectionMatrix();
  renderer.setSize(width, height);
}
resize();
window.addEventListener('resize', resize);

const colorTargets = Object.fromEntries(Object.entries(lighting).map(([key, value]) => [key, {
  sun: new THREE.Color(value.sun), sky: new THREE.Color(value.sky), ground: new THREE.Color(value.ground), fill: new THREE.Color(value.fill),
}]));
let lastTime = performance.now(), frameCount = 0, fpsStart = lastTime, fps = 0;
function frame(time) {
  requestAnimationFrame(frame);
  const delta = Math.min((time - lastTime) / 1000, .1);
  lastTime = time;
  if (document.hidden) return;
  if (tween) {
    const fraction = tween.duration ? Math.min((time - tween.time) / tween.duration, 1) : 1;
    const ease = fraction < .5 ? 4 * fraction ** 3 : 1 - (-2 * fraction + 2) ** 3 / 2;
    camera.position.lerpVectors(tween.fromPosition, tween.toPosition, ease);
    controls.target.lerpVectors(tween.fromTarget, tween.toTarget, ease);
    camera.zoom = THREE.MathUtils.lerp(tween.fromZoom, tween.toZoom, ease);
    camera.updateProjectionMatrix();
    if (fraction === 1) tween = null;
  }
  if (lightTween) {
    const t = lightTween.duration ? Math.min((time - lightTween.start) / lightTween.duration, 1) : 1;
    const p = lightTween.preset, colors = colorTargets[lightMode];
    sun.color.lerpColors(lightTween.sun, colors.sun, t);
    hemi.color.lerpColors(lightTween.sky, colors.sky, t);
    hemi.groundColor.lerpColors(lightTween.ground, colors.ground, t);
    fill.color.lerpColors(lightTween.fill, colors.fill, t);
    sun.intensity = THREE.MathUtils.lerp(lightTween.intensity, p.intensity, t);
    hemi.intensity = THREE.MathUtils.lerp(lightTween.hemi, p.hemi, t);
    renderer.toneMappingExposure = THREE.MathUtils.lerp(lightTween.exposure, p.exposure, t);
    sun.position.lerpVectors(lightTween.position, new THREE.Vector3(...p.position), t);
    if (t === 1) lightTween = null;
  }
  controls.update(delta);
  if (!reducedMotion) updateMotes(time / 1000);
  renderer.render(scene, camera);
  frameCount++;
  if (time - fpsStart > 1200) {
    fps = Math.round(frameCount * 1000 / (time - fpsStart));
    container.dataset.fps = String(fps);
    container.dataset.drawCalls = String(renderer.info.render.calls);
    container.dataset.voxels = String(voxel.count);
    container.dataset.buildings = String(architecture.landmarks.length);
    container.dataset.light = lightMode;
    frameCount = 0; fpsStart = time;
  }
}
renderer.render(scene, camera);
$('#loading').classList.add('ready');
setTimeout(() => $('#loading').remove(), 750);
requestAnimationFrame(frame);

// Read-only diagnostics for the local performance/interaction acceptance checks.
window.__JADE__ = {
  get stats() { return { voxelCount: voxel.count, buildings: architecture.landmarks.length, drawCalls: renderer.info.render.calls, triangles: renderer.info.render.triangles, fps, light: lightMode, selected, autoRotate: controls.autoRotate, topView, zoom: camera.zoom, webgl: renderer.capabilities.isWebGL2 ? 2 : 'supported', size: [innerWidth, innerHeight] }; },
};
