import { defineConfig } from 'vite';

export default defineConfig({
  base: './',
  optimizeDeps: { noDiscovery: true, exclude: ['three'] },
  build: {
    target: 'es2022',
    assetsInlineLimit: 1000000,
    chunkSizeWarningLimit: 900,
  },
});
