import { readFile, writeFile } from 'node:fs/promises';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const dist = resolve(dirname(fileURLToPath(import.meta.url)), '../dist');
let html = await readFile(resolve(dist, 'index.html'), 'utf8');
const scripts = [...html.matchAll(/<script\b[^>]*src="([^"]+)"[^>]*><\/script>/g)];
for (const match of scripts) {
  const code = await readFile(resolve(dist, match[1].replace(/^\.\//, '')), 'utf8');
  html = html.replace(match[0], () => `<script type="module">${code.replace(/<\/script/gi, '<\\/script')}</script>`);
}
const styles = [...html.matchAll(/<link\b[^>]*rel="stylesheet"[^>]*href="([^"]+)"[^>]*>/g)];
for (const match of styles) {
  const css = await readFile(resolve(dist, match[1].replace(/^\.\//, '')), 'utf8');
  html = html.replace(match[0], () => `<style>${css}</style>`);
}
html = html.replace(/<link\b[^>]*rel="modulepreload"[^>]*>/g, '');
const threeLicense = await readFile(resolve(dist, '../node_modules/three/LICENSE'), 'utf8');
html = html.replace('</head>', () => `<!-- Third-party software: Three.js\n${threeLicense}\n-->\n</head>`);
await writeFile(resolve(dist, '山岚古境.html'), html, 'utf8');
await writeFile(resolve(dist, 'THREE-LICENSE.txt'), threeLicense, 'utf8');
console.log('Standalone offline scene: dist/山岚古境.html');
