/** A hand-built, entirely cuboid garden, laid out around the temple axis. */
export function createLandscape(THREE, voxel) {
  const group = new THREE.Group();
  group.name = 'The autumn courtyard';
  const C = {
    grass: '#66795b', grassLight: '#7a8c66', grassDark: '#50674b',
    edge: '#b1ab90', stone: '#d6cfb6', pale: '#e4ddc5', stoneShade: '#b5b49c',
    earth: '#766f59', earthDark: '#514f43', red: '#8d3930', wood: '#684c38',
    jade: '#275452', jadeLight: '#41776b', gold: '#c8a360',
  };
  const box = (x, y, z, w, h, d, color, material = 'default', rotation = 0) =>
    voxel.box(group, x, y, z, w, h, d, color, { material, rotation });
  const hash = (x, z, salt = 0) => {
    const a = Math.sin(x * 127.1 + z * 311.7 + salt * 74.7) * 43758.5453;
    return a - Math.floor(a);
  };
  const choose = (colors, x, z, salt = 0) => colors[Math.floor(hash(x, z, salt) * colors.length)];
  const stone = (x, y, z, w, h, d, color = C.stone) => box(x, y, z, w, h, d, color, 'stone');

  // An exhibition-like island: stepped masonry, warm soil, and a grass cap.
  stone(0, -3.45, 1, 85.5, 1.3, 77.5, '#706f60');
  stone(0, -2.65, 1, 88, .45, 80, '#9c9c84');
  box(0, -1.65, 1, 87.4, 1.6, 79.4, C.earth, 'stone');
  stone(0, -.72, 1, 88, .32, 80, C.edge);
  box(0, -.28, 1, 87.2, .56, 79.2, C.grass);
  for (let x = -42; x <= 42; x += 2) {
    for (const z of [-38.8, 40.8]) {
      stone(x, -1.6, z, 1.94, 1.7, .45, choose(['#7e7963', '#8a8269', '#948c70'], x, z));
      stone(x + .95, -2.14, z + (z > 0 ? .12 : -.12), .1, .54, .5, '#625e4e');
    }
  }
  for (let z = -37; z <= 39; z += 2) {
    for (const x of [-43.8, 43.8]) stone(x, -1.6, z, .45, 1.7, 1.94,
      choose(['#7e7963', '#8a8269', '#948c70'], x, z));
  }
  // A thin limestone frame makes the island edge legible from a distant view.
  stone(0, .045, -38.7, 87.4, .13, .55);
  stone(0, .045, 40.7, 87.4, .13, .55);
  for (const s of [-1, 1]) stone(s * 43.45, .045, 1, .55, .13, 79.6);

  const paving = ['#d0ceb7', '#d8d4bc', '#cecbb2', '#dfdac1', '#c5c5ac'];
  const pathPaving = ['#e5ddc3', '#ddd5bb', '#e8e0c9', '#d5ceb5'];
  const inPond = (x, z, pad = 0) => Math.abs(Math.abs(x) - 16) < 4.65 + pad && z > 8.1 - pad && z < 19.9 + pad;
  // Individual, slightly irregular pavers retain their joints even at this scale.
  for (let x = -14; x <= 14; x += 1.75) {
    for (let z = -8; z <= 20; z += 1.75) {
      if (Math.abs(x) < 4.3 || inPond(x, z, .5)) continue;
      stone(x, .045, z, 1.69, .09, 1.69, choose(paving, x, z));
    }
  }
  // Main processional route and the link to each side hall.
  for (let x = -3.3; x <= 3.31; x += 2.2) {
    for (let z = -12; z <= 36; z += 2.2)
      stone(x, .07, z, 2.13, .14, 2.13, choose(pathPaving, x, z));
  }
  for (const s of [-1, 1]) {
    stone(s * 4.48, .09, 12, .2, .18, 49, C.edge);
    stone(s * 4.7, .065, 12, .12, .13, 49, C.grassDark);
    for (let x = 5.2; x < 26; x += 1.75) {
      for (let z = -6.4; z <= -3; z += 1.7)
        stone(s * x, .07, z, 1.68, .14, 1.63, choose(pathPaving, x, z));
    }
    // A garden promenade, leading over the pond's miniature stone bridge.
    for (let x = 5.4; x <= 29; x += 1.7) {
      if (x > 11.2 && x < 21) continue;
      stone(s * x, .08, 15.5, 1.63, .16, 2.2, choose(pathPaving, x, 15.5));
    }
  }
  // Fine border and a chequered threshold at the start of the main courtyard.
  for (const s of [-1, 1]) stone(s * 14.95, .065, 2, .28, .13, 21.4, C.edge);
  stone(0, .055, 21.1, 30, .11, .32, C.edge);
  for (let x = -13.5; x <= 13.5; x += 1.5)
    stone(x, .09, 22.2, 1.42, .18, 1.42, Math.round(x / 1.5) % 2 ? C.stone : C.stoneShade);

  function pond(s) {
    const x = s * 16, z = 14;
    stone(x, .055, z, 9.2, .11, 12, '#9b9d88');
    box(x, .12, z, 8.1, .16, 10.9, '#285f61');
    box(x, .205, z, 7.95, .025, 10.75, '#387c78');
    const water = ['#428882', '#397c78', '#4c8d83', '#357370', '#55968a'];
    for (let dx = -3.4; dx <= 3.5; dx += .86) {
      for (let dz = -4.6; dz <= 4.7; dz += .86) {
        if (hash(dx, dz, s) > .67) box(x + dx, .225, z + dz, .82, .025, .82, choose(water, dx, dz, s));
      }
    }
    for (let i = -5; i <= 5; i++) {
      for (const side of [-1, 1]) stone(x + side * 4.35, .3, z + i, .65, .48, .94,
        choose([C.stone, C.pale, '#c9cbb2'], i, side));
    }
    for (let i = -4; i <= 4; i++) {
      for (const side of [-1, 1]) stone(x + i, .3, z + side * 5.7, .94, .48, .65,
        choose([C.stone, C.pale, '#c9cbb2'], i, side));
    }
    // Lily clusters and small warm reflections.
    for (const [dx, dz] of [[-2.2, -3.5], [1.8, 3.1], [2.1, -2.6]]) {
      box(x + s * dx, .25, z + dz, .84, .08, .6, '#71894f');
      box(x + s * dx + .2, .27, z + dz + .22, .58, .08, .55, '#92a05e');
      box(x + s * dx, .34, z + dz, .28, .16, .28, '#e7d7ae');
      box(x + s * dx, .445, z + dz, .12, .08, .12, '#d5ab5e');
    }
    // A restrained flat stone bridge with stepped ends and squared balusters.
    stone(x, .42, 15.5, 9.6, .5, 2.25, C.stoneShade);
    for (let j = -5; j <= 5; j++) stone(x + j * .84, .72, 15.5, .8, .12, 2.32, C.pale);
    for (const side of [-1, 1]) {
      stone(x + side * 5.15, .22, 15.5, .8, .3, 2.25);
    }
    for (const dz of [-1.04, 1.04]) {
      stone(x, 1.18, 15.5 + dz, 8.6, .17, .2, '#d7d3b7');
      for (let j = -4; j <= 4; j += 2) {
        stone(x + j, .98, 15.5 + dz, .25, .6, .25, '#c1c7ad');
        stone(x + j, 1.35, 15.5 + dz, .34, .18, .34, C.pale);
      }
    }
  }
  pond(-1); pond(1);

  // Low boundary walls, with red panels and jade coping blocks.
  function wallRun(axis, fixed, a, b) {
    const length = b - a;
    const center = (a + b) / 2;
    const place = (along, y, w, h, depth, color, material = 'stone') =>
      axis === 'z' ? box(fixed, y, along, depth, h, w, color, material)
        : box(along, y, fixed, w, h, depth, color, material);
    place(center, .35, length, .7, 1.02, '#c5c1a7');
    place(center, 1.12, length, 1.05, .72, '#e2d7bd');
    place(center, 1.72, length + .24, .26, 1.1, C.jade, 'roof');
    place(center, 1.92, length + .12, .16, .82, C.jadeLight, 'roof');
    for (let p = a + .4; p < b; p += 6.5) {
      place(p, 1.1, .68, 1.75, 1.12, '#c3bda5');
      place(p, 2.03, .88, .2, 1.3, C.jade, 'roof');
      if (p + 5.2 < b) place(p + 3.2, 1.12, 4.5, .73, .76, C.red);
    }
  }
  wallRun('z', -41, -35.7, 34);
  wallRun('z', 41, -35.7, 34);
  wallRun('x', -35.7, -41, 41);
  wallRun('x', 34, -41, -10.5);
  wallRun('x', 34, 10.5, 41);

  function planter(x, z, w = 5.8, d = 5.8) {
    stone(x, .16, z, w, .32, d, '#b3b598');
    box(x, .36, z, w - .5, .12, d - .5, '#6e714f');
    for (const s of [-1, 1]) {
      stone(x + s * (w / 2 - .18), .42, z, .36, .22, d, C.stone);
      stone(x, .42, z + s * (d / 2 - .18), w, .22, .36, C.stone);
    }
  }
  function leafLayer(x, y, z, radius, palette, seed, cell = .78, thickness = .85) {
    const n = Math.ceil(radius / cell);
    for (let ix = -n; ix <= n; ix++) for (let iz = -n; iz <= n; iz++) {
      const dx = ix * cell, dz = iz * cell;
      if (Math.max(Math.abs(dx), Math.abs(dz)) > radius) continue;
      if (Math.abs(dx) + Math.abs(dz) > radius * 1.58) continue;
      if (hash(ix, iz, seed) < .055 && Math.abs(dx) + Math.abs(dz) > radius) continue;
      box(x + dx, y + hash(ix, iz, seed + 9) * .15, z + dz,
        cell + .015, thickness, cell + .015, choose(palette, ix, iz, seed));
    }
  }
  function pine(x, z, scale, seed) {
    const palette = ['#244e46', '#2e5b4d', '#3c6752', '#426d52', '#2b5448'];
    box(x, 4.3 * scale, z, .88 * scale, 8.6 * scale, .88 * scale, C.wood, 'wood');
    box(x - .29 * scale, 3.1 * scale, z + .46 * scale, .2 * scale, 5.8 * scale, .08, '#8c6b46', 'wood');
    for (let i = 0; i < 5; i++) {
      const y = (3.6 + i * 1.55) * scale;
      const r = (3.8 - i * .66) * scale;
      leafLayer(x, y, z, r, palette, seed + i, .8 * scale, .9 * scale);
      leafLayer(x, y + .65 * scale, z, r - .6 * scale, palette, seed + i + 10, .8 * scale, .65 * scale);
    }
    box(x, 10.8 * scale, z, .65 * scale, 1.2 * scale, .65 * scale, '#527851');
    for (const side of [-1, 1]) box(x + side * 1.15 * scale, 3.0 * scale, z, 2.1 * scale, .35 * scale, .4 * scale, C.wood, 'wood');
  }
  function autumnTree(x, z, seed, isRed = false) {
    planter(x, z, 5.9, 5.9);
    const bark = '#6d4c35';
    box(x, 3.1, z, .9, 5.6, .9, bark, 'wood');
    box(x + .5, 4.4, z, 1.8, .55, .55, bark, 'wood');
    box(x + 1.2, 5.1, z, .55, 1.6, .55, bark, 'wood');
    box(x - .7, 4.0, z + .5, 1.9, .6, .55, bark, 'wood');
    box(x - 1.4, 4.5, z + .5, .55, 1.6, .55, bark, 'wood');
    const palette = isRed
      ? ['#a94e32', '#bc6139', '#cf7840', '#d58b4b', '#9b4630']
      : ['#b8933e', '#cda64a', '#dfb956', '#e7c667', '#d4aa42'];
    leafLayer(x, 5.25, z, 2.9, palette, seed, .82, .9);
    leafLayer(x, 6.13, z, 3.7, palette, seed + 1, .82, .9);
    leafLayer(x - .45, 7.02, z, 3.15, palette, seed + 2, .82, .9);
    leafLayer(x + .35, 7.89, z - .2, 2.3, palette, seed + 3, .82, .9);
    leafLayer(x, 8.6, z, 1.3, palette, seed + 4, .82, .65);
    // Fallen leaves add an autumn note without concealing the paving.
    for (let i = 0; i < 24; i++) {
      const dx = (hash(i, seed) - .5) * 9, dz = (hash(seed, i) - .5) * 9;
      if (inPond(x + dx, z + dz, .2)) continue;
      box(x + dx, .15, z + dz, .22 + hash(i, seed + 3) * .16, .06, .26, choose(palette, i, seed));
    }
  }
  // Carefully placed silhouettes: tall pines frame the hall, maples frame the garden.
  for (const s of [-1, 1]) {
    pine(s * 35, -29, 1.08, s + 12);
    pine(s * 37, -19, .72, s + 23);
    pine(s * 26, -31, .67, s + 35);
    autumnTree(s * 26, 11.4, s + 45, s < 0);
  }

  function bush(x, z, size, seed) {
    const palette = ['#506e48', '#648052', '#78925e', '#87975f'];
    box(x, .35, z, size * 1.3, .5, size * 1.2, '#465e43');
    leafLayer(x, .75, z, size, palette, seed, .55, .65);
    leafLayer(x, 1.26, z, size * .65, palette, seed + 1, .55, .5);
  }
  for (const s of [-1, 1]) {
    for (const [x, z, size] of [[35, 8, 1.45], [36, 12, 1.2], [34, 32, 1.35], [22, 32, 1.3], [19, -32, 1.3], [35, -6, 1.2], [35, -10, 1.45]])
      bush(s * x, z, size, x + z);
  }
  // Tufts are low and sparse, keeping every path easy to read.
  for (let x = -38; x <= 38; x += 2.2) for (let z = -32; z <= 31; z += 2.4) {
    if (Math.abs(x) < 17 || hash(x, z) < .73) continue;
    if ((Math.abs(x) > 17 && Math.abs(x) < 33 && z > -17 && z < 7)
      || (Math.abs(x) > 24 && Math.abs(x) < 38 && z > 18 && z < 30)
      || (Math.abs(x) < 22 && z > 7 && z < 21)
      || Math.abs(z - 15.5) < 2 || Math.abs(z + 5) < 3) continue;
    const h = .23 + hash(x, z, 1) * .28;
    box(x, h / 2 + .03, z, .18, h, .18, '#91a070');
    box(x + .28, h / 3 + .03, z + .17, .14, h * .65, .14, '#819263');
  }

  function lantern(x, z) {
    stone(x, .15, z, 1.45, .3, 1.45, C.stoneShade);
    stone(x, .4, z, 1.1, .2, 1.1, C.stone);
    stone(x, 1.1, z, .43, 1.25, .43, '#c5c7ac');
    stone(x, 1.75, z, 1.2, .22, 1.2, C.pale);
    box(x, 2.18, z, .64, .7, .64, '#e5bb6c', 'gold');
    for (const sx of [-1, 1]) for (const sz of [-1, 1])
      stone(x + sx * .42, 2.15, z + sz * .42, .17, .84, .17, '#bec3a8');
    stone(x, 2.6, z, 1.1, .2, 1.1, C.stone);
    stone(x, 2.8, z, 1.52, .2, 1.52, '#7d9681');
    stone(x, 2.99, z, 1.08, .18, 1.08, '#96a68b');
    stone(x, 3.17, z, .64, .2, .64, '#a8b497');
    stone(x, 3.39, z, .24, .3, .24, C.pale);
  }
  for (const s of [-1, 1]) {
    lantern(s * 7.1, 18.4);
    lantern(s * 11.5, -6.8);
    lantern(s * 35, 16.5);
    lantern(s * 13.1, 30.5);
  }

  // A bronze incense burner gives the courtyard a focal detail at human scale.
  stone(0, .18, -1.9, 4.2, .36, 3.7, '#b9bba4');
  stone(0, .44, -1.9, 3.5, .18, 3.0, C.pale);
  for (const sx of [-1, 1]) for (const sz of [-1, 1])
    box(sx * .88, .95, -1.9 + sz * .64, .36, 1.1, .36, '#426b5e', 'dark');
  box(0, 1.67, -1.9, 2.55, .8, 1.95, '#466e5d', 'dark');
  box(0, 1.42, -1.9, 2.18, .3, 1.68, '#345549', 'dark');
  box(0, 2.15, -1.9, 2.78, .18, 2.15, '#b7a36a', 'gold');
  box(0, 2.25, -1.9, 2.25, .06, 1.62, '#3e4a3d', 'dark');
  for (const s of [-1, 1]) {
    box(s * 1.58, 2.0, -1.9, .22, 1.0, 1.0, '#517666', 'dark');
    box(s * 1.4, 2.5, -1.9, .58, .2, 1.0, '#75917a', 'dark');
  }
  for (let i = -2; i <= 2; i++) {
    box(i * .22, 2.78 + Math.abs(i) * .05, -1.9 + (i % 2) * .15, .07, 1.1, .07, '#9f633e', 'wood');
    box(i * .22, 3.35 + Math.abs(i) * .05, -1.9 + (i % 2) * .15, .09, .08, .09, '#e0a364', 'gold');
  }

  // Simple block benches sit under the autumn foliage.
  for (const s of [-1, 1]) {
    for (const z of [7.2, 17.8]) {
      box(s * 28.9, .92, z, 3.4, .27, 1.08, '#8b6342', 'wood');
      for (const dx of [-1.1, 1.1]) stone(s * 28.9 + dx, .45, z, .42, .8, .76, '#b9bba0');
    }
  }
  return { group, animated: [] };
}
