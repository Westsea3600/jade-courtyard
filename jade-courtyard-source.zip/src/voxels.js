/** Collect transformed cuboids, then draw them as a handful of colored instances. */
export class VoxelBatch {
  constructor(THREE) {
    this.THREE = THREE;
    this.entries = [];
    this.count = 0;
    this.meshes = [];
  }

  box(parent, x, y, z, w, h, d, color, options = {}) {
    if (![x, y, z, w, h, d].every(Number.isFinite) || w <= 0 || h <= 0 || d <= 0) {
      throw new Error('Invalid voxel dimensions');
    }
    this.entries.push({parent, x, y, z, w, h, d, color, options});
  }

  build(scene) {
    const T = this.THREE;
    scene.updateMatrixWorld(true);
    const buckets = new Map();
    const transform = new T.Object3D();
    const matrix = new T.Matrix4();
    const color = new T.Color();
    for (const entry of this.entries) {
      const key = entry.options.material || 'default';
      if (!buckets.has(key)) buckets.set(key, []);
      buckets.get(key).push(entry);
    }
    const geometry = new T.BoxGeometry(1, 1, 1);
    for (const [key, entries] of buckets) {
      const material = new T.MeshStandardMaterial({
        color: 0xffffff,
        roughness: key === 'gold' ? 0.48 : key === 'roof' ? 0.76 : 0.93,
        metalness: key === 'gold' ? 0.30 : 0,
      });
      const mesh = new T.InstancedMesh(geometry, material, entries.length);
      mesh.name = `voxels-${key}`;
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      entries.forEach((entry, index) => {
        transform.position.set(entry.x, entry.y, entry.z);
        transform.scale.set(entry.w, entry.h, entry.d);
        transform.rotation.set(0, entry.options.rotation || 0, 0);
        transform.updateMatrix();
        matrix.multiplyMatrices(entry.parent.matrixWorld, transform.matrix);
        mesh.setMatrixAt(index, matrix);
        mesh.setColorAt(index, color.set(entry.color));
      });
      mesh.instanceMatrix.setUsage(T.StaticDrawUsage);
      mesh.computeBoundingBox();
      mesh.computeBoundingSphere();
      scene.add(mesh);
      this.meshes.push(mesh);
      this.count += entries.length;
    }
    this.entries = [];
    return this.meshes;
  }
}
